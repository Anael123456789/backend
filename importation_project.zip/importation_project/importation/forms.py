from django import forms  
class ImportationSimulationForm(forms.Form):
    units = forms.IntegerField(label="Cantidad de Unidades", min_value=1)  # Campo de entrada para la cantidad de unidades con etiqueta "Cantidad de Unidades" y valor mínimo de 1.
    unit_cost_usd = forms.DecimalField(label="Costo Unitario (USD)")  # Campo de entrada para el costo unitario en USD con etiqueta "Costo Unitario (USD)".
    article_name = forms.CharField(label="Nombre del Artículo")  
    article_code = forms.CharField(label="Código del Artículo") 
    provider_name = forms.CharField(label="Nombre del Proveedor") 
    shipping_cost_usd = forms.DecimalField(label="Costo de Envío a Chile (USD)")  
