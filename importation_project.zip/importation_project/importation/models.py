from django.db import models 

class ImportationSimulation(models.Model):
    units = models.IntegerField()  # Campo que almacena la cantidad de unidades, como un número entero.
    unit_cost_usd = models.DecimalField(max_digits=10, decimal_places=2)  # Campo para el costo unitario en USD con 10 dígitos y 2 decimales.
    article_name = models.CharField(max_length=100) 
    article_code = models.CharField(max_length=50)
    provider_name = models.CharField(max_length=100) 
    shipping_cost_usd = models.DecimalField(max_digits=10, decimal_places=2)  
    total_purchase_cost_clp = models.DecimalField(max_digits=10, decimal_places=2)
    total_purchase_cost_usd = models.DecimalField(max_digits=10, decimal_places=2) 
    created_at = models.DateTimeField(auto_now_add=True) 
