from django.urls import path  
from . import views  # para importar las vistas definidas en el mismo directorio donde se encuentra este archivo.

urlpatterns = [
    path('importation_simulation/', views.importation_simulation, name='importation_simulation'),  
]
