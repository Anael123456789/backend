from django.shortcuts import render  
from decimal import Decimal 
from .forms import ImportationSimulationForm  
from .models import ImportationSimulation 

def importation_simulation(request):
    if request.method == "POST": 
        form = ImportationSimulationForm(request.POST)  # Crea una instancia del formulario con los datos de la solicitud.
        if form.is_valid(): 
            units = form.cleaned_data['units']  # cada uno obtiene los datos del formulario del formulario.
            unit_cost_usd = form.cleaned_data['unit_cost_usd']  
            article_name = form.cleaned_data['article_name']  
            article_code = form.cleaned_data['article_code']  
            provider_name = form.cleaned_data['provider_name']  
            shipping_cost_usd = form.cleaned_data['shipping_cost_usd']  

            total_cost_usd = units * unit_cost_usd  

            # Conversión a Decimal para cálculos precisos
            total_cost_clp = Decimal(total_cost_usd) * Decimal('890.00')  
            shipping_cost_clp = Decimal(shipping_cost_usd) * Decimal('890.00')  # calculos para la tabla de resultados.
            customs_tax_clp = total_cost_clp * Decimal('0.06')  
            vat_clp = total_cost_clp * Decimal('0.19') 
            total_import_tax_clp = customs_tax_clp + vat_clp  
            total_purchase_cost_clp = total_cost_clp + shipping_cost_clp + total_import_tax_clp  
            total_purchase_cost_usd = total_cost_usd + shipping_cost_usd + (total_import_tax_clp / Decimal('890.00')).quantize(Decimal('0.00'))

            # Crea una instancia de ImportationSimulation y la guarda en la base de datos
            simulation = ImportationSimulation(
                units=units,
                unit_cost_usd=unit_cost_usd,
                article_name=article_name,
                article_code=article_code,
                provider_name=provider_name,
                shipping_cost_usd=shipping_cost_usd,
                total_purchase_cost_clp=total_purchase_cost_clp,
                total_purchase_cost_usd=total_purchase_cost_usd
            )
            simulation.save()

            simulations = ImportationSimulation.objects.all()  # es para tener u obtener todas las simulaciones

            return render(
                request,
                "importation/importation_simulation.html",
                {
                    "form": form,
                    "simulations": simulations,
                    "total_cost_clp": total_cost_clp,
                    "shipping_cost_clp": shipping_cost_clp,
                    "customs_tax_clp": customs_tax_clp,
                    "vat_clp": vat_clp,
                    "total_import_tax_clp": total_import_tax_clp,
                    "total_purchase_cost_clp": total_purchase_cost_clp,
                    "total_purchase_cost_usd": total_purchase_cost_usd,
                },
            )

    else:
        form = ImportationSimulationForm()  # Crea una instancia vacía del formulario.
        simulations = ImportationSimulation.objects.all()  # Obtiene todas las simulaciones existentes en la base de datos.

        return render(
            request,
            "importation/importation_simulation.html",
            {"form": form, "simulations": simulations},
        )
