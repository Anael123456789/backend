from django.contrib import admin
from django.urls import path, include
from importation.views import importation_simulation
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),  # para el panel de administración de Django
    path('', importation_simulation, name='importation_simulation'),  #  y esto carga la vista de simulación
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)